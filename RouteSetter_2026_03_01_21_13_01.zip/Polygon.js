class Polygon {
  constructor(x, y, radius, npoints) {
    this.x = x;
    this.y = y;
    this.radius = radius;
    this.npoints = npoints;
    this.angle = TWO_PI / npoints;
  }

  draw() {
    beginShape();
    for (let a = 0; a < TWO_PI; a += this.angle) {
      let sx = this.x + cos(a) * this.radius;
      let sy = this.y + sin(a) * this.radius;
      vertex(sx, sy);
    }
    endShape(CLOSE);
  }

  clicked() {
    let d = dist(mouseX, mouseY, this.x, this.y);
    if (d > holds.r) {
      console.log("Clicked On Hold");
    }
  }
}

function add(x, y) {
  return x + y;
}

//credit to https://editor.p5js.org/mahdadbor/sketches/-JCLLuP8R
// function polygon(x, y, radius, npoints){
//     let angle = TWO_PI / npoints;
//     beginShape();
//     for (let a = 0; a < TWO_PI; a += angle){
//       let sx = x + cos(a) * radius;
//       let sy = y + sin(a) * radius;
//       vertex(sx, sy);
//     }
//     endShape(CLOSE);
//   }

// function mousePressed(){

//   polygon(mouseX, mouseY, 20, random(3, 8));
//   console.log(mouseX, mouseY);
//   }
