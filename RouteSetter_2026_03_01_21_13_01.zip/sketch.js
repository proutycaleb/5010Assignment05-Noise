let holds = [];

function setup() {
  createCanvas(400, 800);
  noLoop();
  frameRate(0);
  background(194);
}

function draw() {
  let LC = random(50, 300);

  let a = random(0, LC);
  let b = random(0, LC);
  let c = random(100, 400);
  let d = random(0, LC);
  let e = c + random(0, c);
  let f = random(0, LC);

  let g = random(LC, 400);
  let h = random(LC, 400);
  let i = random(100, 400);
  let j = random(LC, 400);
  let k = i + random(0, i);
  let l = random(LC, 400);

  line(a, 0, b, c);
  line(b, c, d, e);
  line(d, e, f, 800);

  line(g, 0, h, i);
  line(h, i, j, k);
  line(j, k, l, 800);

  fill(random(0, 255), random(0, 255), random(0, 255));

  let p1 = new Polygon(200, 750, 20, random(3, 8));

  p1.draw();
}

function mousePressed() {
  let p2 = new Polygon(mouseX, mouseY, 20, random(3, 8));

    p2.draw();
    holds.push(p2);

    console.log(holds.length);
  
  for (let i = 0; i < holds.length; i++) {
    holds[i].clicked(mouseX, mouseY);
  }
}






let sum = add(3, 2);
console.log(sum);
